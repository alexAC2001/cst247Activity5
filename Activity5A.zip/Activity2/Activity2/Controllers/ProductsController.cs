﻿using Activity2.Models;
using Activity2.Services;
using Bogus;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Activity2.Controllers
{
    public class ProductsController : Controller
    {
        ProductsDAO repository = new ProductsDAO();
        public ProductsController()
        {
            repository = new ProductsDAO();
        }

        // Index method
        public IActionResult Index()
        {
            return View(repository.AllProducts());
            
            /*// Instantiate the data repository
            HardCodedSampleDataRepository repository = new HardCodedSampleDataRepository();
            // Get all the data records via the AllProducts method.
            return View(repository.AllProducts());*/
        }

        // Search Results
        public IActionResult SearchResults(string searchTerm)
        {
            List<ProductModel> productList = repository.SearchProducts(searchTerm);
            return View("Index", productList);
        }

        // Allow the user to perform a search
        public IActionResult SearchForm()
        {
            return View();
        }

        public IActionResult ShowOneProduct(int Id)
        {
            return View(repository.GetProductById(Id));
        }
        public IActionResult ShowOneProductJSON(int Id)
        {
            return Json(repository.GetProductById(Id));
        }

        // Go to editing view
        public IActionResult ShowEditForm(int Id)
        {
            return View(repository.GetProductById(Id));
        }

        // Update the product
        public IActionResult ProcessEdit(ProductModel product)
        {
            repository.Update(product);
            return View("Index", repository.AllProducts());
        }

        // For Activty 4 PARTIAL VIEWS
        public IActionResult ProcessEditReturnPartial(ProductModel product)
        {
            repository.Update(product);
            return PartialView("_productCard", product); // Return a card
            //return PartialView("_productCard", repository.GetProductById(product.Id));
        }

        // Delete method
        public IActionResult Delete(ProductModel product)
        {
            repository.Delete(product);
            return View("Index");
        }

        /*public IActionResult Message()
        {
            return View("message");
        }*/
        public IActionResult Welcome()
        {
            ViewBag.name = "Alex";
            ViewBag.secretNumber = 13;
            return View();
        }
        /*public string Message()
        {
            return "This is an important message about some product thing";
        }*/
        /*public IActionResult Welcome(string name, int secretNumber=13)
        {
            ViewBag.Name = name;
            ViewBag.Secret = secretNumber;
            return View(); // Assumed that it is welcome
        }*/
        /*public string Welcome(string name, int secretNumber = 13)
        {
            return HttpUtility.HtmlEncode("Hello " + name + "the secret number is " + secretNumber);
        }*/
    }
}
