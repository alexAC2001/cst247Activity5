﻿using Activity2.Models;
using Activity2.Services;
using Bogus;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Activity2.Controllers
{
    // Declarations
    [ApiController]
    [Route("api/")]
    public class ProductsControllerAPI : ControllerBase // We're not returning views here
    {
        ProductsDAO repository = new ProductsDAO();

        // Constructor
        public ProductsControllerAPI()
        {
            repository = new ProductsDAO();
        }

        // Index method
        [HttpGet] // Get request so we can get items
        // Produce a list of products in JSON format
        public ActionResult <IEnumerable<ProductModel>>Index()
        {
            return (repository.AllProducts());
        }

        // Search Results
        [HttpGet("searchproducts/{searchTerm}")]
        public ActionResult <IEnumerable<ProductModel>> SearchResults(string searchTerm)
        {
            return repository.SearchProducts(searchTerm);
        }

        /*[HttpGet("ShowOneProduct/{Id}")] // Type of request
        public ActionResult <ProductModel> ShowOneProduct(int Id)
        {
            return repository.GetProductById(Id);
        }*/
        [HttpGet("ShowOneProduct/{Id}")] // Type of request
        public ActionResult<ProductModelDTO> ShowOneProductDTO(int Id)
        {
            ProductModel p = repository.GetProductById(Id);
            ProductModelDTO pDTO = new ProductModelDTO(p);
            return pDTO;
        }


        [HttpPost("InsertOne")]
        // post action
        // expecting a product in json format in the body of the request
        public ActionResult<int> InsertOne(ProductModel product)
        {
            int newId = repository.Insert(product);
            return newId;
        }

        // Update the product (PUT request)
        [HttpPut("ProcessEdit")]
        // put request
        // expect a json formatted object in the body of the request, id number must match the item being updated
        public ActionResult <ProductModel> ProcessEdit(ProductModel product)
        {
            repository.Update(product);
            return repository.GetProductById(product.Id);
        }
        // Delete method
        [HttpDelete("DeleteOne/{Id}")]
        public ActionResult <bool> DeleteOne(int Id)
        {
            ProductModel deleteMe = repository.GetProductById(Id);
            bool success = repository.Delete(deleteMe);
            return success;
        }
    }
}
