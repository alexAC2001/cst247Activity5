﻿using Activity2.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Activity2.Controllers
{
    public class MovieController : Controller
    {
        public IActionResult Index()
        {
            // Instantiate the data repository
            MovieHardCodedSampleDataRepository repository = new MovieHardCodedSampleDataRepository();
            // Get all the data records via the AllProducts method.
            return View(repository.AllProducts());
        }
    }
}
