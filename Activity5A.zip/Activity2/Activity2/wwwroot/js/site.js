﻿$(function () {
    console.log("document ready");
    // this button click fills the modal form with data and displays it.
    $(document).on("click", ".edit-product-button", function () {
        console.log("You just clicked the button number " + $(this).val());

        // store the product id number
        var productID = $(this).val();

        // ajax is a javascript way to talk to the server
        // ajax function
        $.ajax({
            type: 'json',
            data: {
                "id": productID
            },
            url: '/products/ShowOneProductJSON',
            success: function (data) {
                console.log(data)

                // fill in the input fields

                $("#modal-input-id").val(data.id);
                $("#modal-input-name").val(data.name)
                $("#modal-input-price").val(data.price);
                $("#modal-input-description").val(data.description);
            }
        })
    });
    $("#save-button").click(function () {
        // Get the values from the input fields and create a json object to submit to the controller
        var Product = {
            "Id": $("#modal-input-id").val(),
            "Name": $("#modal-input-name").val(),
            "Price": $("#modal-input-price").val(),
            "Description": $("#modal-input-description").val()
    };
        console.log("saved...");
        console.log(Product);

        // save the updated produdct record in the database using the controller
        $.ajax({
            type: 'json',
            data: Product,
            url:'/products/ProcessEditReturnPartial',
            success:function (data) {
                console.log(data);
                $("#card-number-" + Product.Id).html(data); // Get the current product
            }
        })

    })
});