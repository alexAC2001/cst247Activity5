﻿using Activity2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Activity2.Services
{
    public interface MovieIProductsDataService
    {
        List<MovieModel> AllProducts();
        List<MovieModel> SearchProducts(string searchTerm);
        MovieModel GetProductById(int id);
        int Insert(MovieModel product);
        bool Delete(MovieModel product);
        int Update(MovieModel product);        
    }
}
