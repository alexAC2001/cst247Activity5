﻿using Activity2.Models;
using Bogus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Activity2.Services
{
    public class MovieHardCodedSampleDataRepository : MovieIProductsDataService
        // All methods are implemented here since this class extends from the interface.
    {
        // use static to ensure the data set does not change
        static List<MovieModel> movieList;

        public MovieHardCodedSampleDataRepository()
        {
            movieList = new List<MovieModel>();
            movieList.Add(new MovieModel(1, "Avengers", 14.99m, "Marvel's heroes come together to defeat bad guys!"));
            movieList.Add(new MovieModel(2, "Halloween", 10.50m, "A scary movie featuring Micheal Myers"));
            movieList.Add(new MovieModel(3, "Star Wars", 13.45m, "A space opera."));
            movieList.Add(new MovieModel(4, "Godzilla", 12.99m, "A radioactive dinosaur destroys Tokyo."));
            // Generate fake data
            for (int i = 0; i < 100; i++)
            {
                movieList.Add(new Faker<MovieModel>()
                    .RuleFor(p => p.Id, i + 5)
                    .RuleFor(p => p.Name, f => f.Commerce.ProductName())
                    .RuleFor(p => p.Price, f => f.Random.Decimal(100))
                    .RuleFor(p => p.Description, f => f.Rant.Review())
                    );
            }
        }

        public List<MovieModel> AllProducts()
        {
            return movieList;
        }

        public bool Delete(MovieModel product)
        {
            throw new NotImplementedException();
        }

        public MovieModel GetProductById(int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(MovieModel product)
        {
            throw new NotImplementedException();
        }

        public List<MovieModel> SearchProducts(string searchTerm)
        {
            throw new NotImplementedException();
        }

        public int Update(MovieModel product)
        {
            throw new NotImplementedException();
        }
    }
}
